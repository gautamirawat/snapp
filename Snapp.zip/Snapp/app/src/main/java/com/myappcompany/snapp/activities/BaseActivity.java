package com.myappcompany.snapp.activities;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.camera.CameraPreviewActivity;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

@SuppressLint("Registered")
public class BaseActivity extends AppCompatActivity {

    protected FirebaseFirestore mFireStore;
    protected ActionBar supportActionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        supportActionBar = getSupportActionBar();
        supportActionBar.setTitle(getString(R.string.app_name));

        if (this instanceof SplashScreenActivity || this instanceof RegisterActivity
                || this instanceof LoginActivity || this instanceof CameraPreviewActivity) {
            return;
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            return;
        }

        mFireStore = FirebaseFirestore.getInstance();

        FireBaseDataInstance.getInstance().readUsers(mFireStore, false, null);

        hideKeyboard();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private ProgressDialog dialog;

    protected void displayProgressBar(String message) {
        dismissProgress();
        if (dialog == null)
            dialog = new ProgressDialog(this, R.style.MyDialogTheme);
        dialog.setMessage(message);
        dialog.setCancelable(false);
        dialog.show();
    }

    protected void dismissProgress() {
        if (dialog != null) {
            dialog.dismiss();
            dialog.cancel();
        }
    }

    protected void displayAlert(@NonNull String message, String title, @NonNull String positiveTxt, String negativeTxt,
                                DialogInterface.OnClickListener positiveListener, DialogInterface.OnClickListener negativeListener) {
        if (message.length() == 0 || positiveTxt.length() == 0)
            return;

        AlertDialog.Builder dialog = new AlertDialog.Builder(this, R.style.MyDialogTheme);
        dialog.setMessage(message);
        if (title != null && title.length() > 0) {
            dialog.setTitle(title);
        }
        dialog.setPositiveButton(positiveTxt, positiveListener);
        if (negativeTxt != null && negativeTxt.length() > 0) {
            dialog.setNegativeButton(negativeTxt, negativeListener);
        }
        dialog.show();
    }

    protected void displayAlert(@NonNull String message, String title, @NonNull String positiveTxt, String negativeTxt) {
        if (message.length() == 0 || positiveTxt.length() == 0)
            return;

        AlertDialog.Builder dialog = new AlertDialog.Builder(this, R.style.MyDialogTheme);
        dialog.setMessage(message);
        if (title != null && title.length() > 0) {
            dialog.setTitle(title);
        }
        dialog.setPositiveButton(positiveTxt, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        if (negativeTxt != null && negativeTxt.length() > 0) {
            dialog.setNegativeButton(negativeTxt, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
        }
        dialog.show();
    }

    protected void hideKeyboard() {
        /*InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = getCurrentFocus();
        if (view == null)
            view = new View(this);
        if (imm != null)
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);*/

        /*InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (imm != null)
            imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);*/

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
}
