package com.myappcompany.snapp.activities;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.adapters.ChatMessagesAdapter;
import com.myappcompany.snapp.adapters.UserAdapter;
import com.myappcompany.snapp.model.Chat;
import com.myappcompany.snapp.model.Message;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_CHATS;

public class ChatActivity extends BaseActivity {

    private RelativeLayout chatBottomRl;
    private RecyclerView chatRv;
    private SwipeRefreshLayout chatRefreshLayout;
    private TextView newChatTitleTv;
    private EditText groupChatTitleEt;
    private TextInputLayout groupChatTitleEtL;
    private ImageView selfProfileIv;
    private EditText newMessageEt;
    private TextView sendMessageTv;
    private UserAdapter userAdapter;

    public static final String EXTRA_IS_NEW_CHAT = "isNewChat";
    public static final String EXTRA_IS_NEW_GROUP = "isNewGroupChat";
    public static final String EXTRA_CHAT = "chatObject";
    public static final String EXTRA_CHAT_TITLE = "chatTitle";
    public static final String EXTRA_USERS_MAP = "usersMap";

    private Users currentUser;
    private ArrayList<Users> usersList = new ArrayList<>();
    private HashMap<String, Users> usersMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.chat_subtitle) + "'>" + getString(R.string.chat) + "</font>"));
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        chatBottomRl = findViewById(R.id.chat_bottom_rl);
        chatRv = findViewById(R.id.chats_rv);
        chatRv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        chatRefreshLayout = findViewById(R.id.chat_refresh_layout);
        newChatTitleTv = findViewById(R.id.new_chat_title_tv);
        groupChatTitleEt = findViewById(R.id.group_chat_title_et);
        groupChatTitleEtL = findViewById(R.id.group_chat_title_et_layout);
        selfProfileIv = findViewById(R.id.chat_self_profile_iv);
        newMessageEt = findViewById(R.id.message_et);
        sendMessageTv = findViewById(R.id.send_message_tv);

        usersMap = (HashMap<String, Users>) getIntent().getSerializableExtra(EXTRA_USERS_MAP);

        currentUser = FireBaseDataInstance.getInstance().getCurrentUser();

        chatRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (loadChatsCalled) {
                    loadChats();
                } else {
                    init(true);
                }
            }
        });

        chatRefreshLayout.setRefreshing(true);
        init(false);
    }

    private ArrayList<String> userEmailsList = new ArrayList<>();

    private void init(boolean forceReadUsers) {
        if (getIntent().getBooleanExtra(EXTRA_IS_NEW_GROUP, false)) {
            newChatTitleTv.setText(R.string.select_multiple_contacts);
            groupChatTitleEt.setVisibility(View.VISIBLE);
            groupChatTitleEtL.setVisibility(View.VISIBLE);
            FireBaseDataInstance.getInstance().readUsers(mFireStore, forceReadUsers, new FireBaseDataInstance.Delegate() {
                @Override
                public void onComplete(Object object) {
                    usersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();

                    userAdapter = new UserAdapter(ChatActivity.this, mFireStore, usersList, false, new UserAdapter.Delegate() {
                        @Override
                        public void onItemClick(int position) {
                            String email = usersList.get(position).getEmail();
                            if (userEmailsList.contains(email)) {
                                userEmailsList.remove(email);
                            } else {
                                userEmailsList.add(email);
                            }
                            updateSelectedUsersText();
                        }
                    });
                    userAdapter.setCurrentUser(currentUser);
                    chatRv.setAdapter(userAdapter);
                    userAdapter.notifyDataSetChanged();
                    chatRefreshLayout.setRefreshing(false);
                }
            });
        } else if (getIntent().getBooleanExtra(EXTRA_IS_NEW_CHAT, false)) {
            FireBaseDataInstance.getInstance().readUsers(mFireStore, forceReadUsers, new FireBaseDataInstance.Delegate() {
                @Override
                public void onComplete(Object object) {
                    usersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();

                    userAdapter = new UserAdapter(ChatActivity.this, mFireStore, usersList, false, new UserAdapter.Delegate() {
                        @Override
                        public void onItemClick(int position) {
                            if (!chatRefreshLayout.isRefreshing()) {
                                ArrayList<String> userEmailList = new ArrayList<>();
                                userEmailList.add(usersList.get(position).getEmail());
                                getChatIfExist(userEmailList);
                            }

                        }
                    });
                    userAdapter.setCurrentUser(currentUser);
                    chatRv.setAdapter(userAdapter);
                    userAdapter.notifyDataSetChanged();
                    chatRefreshLayout.setRefreshing(false);
                }
            });
        } else {
            newChatTitleTv.setVisibility(View.GONE);
            chatBottomRl.setVisibility(View.VISIBLE);
            currentChat = (Chat) getIntent().getSerializableExtra(EXTRA_CHAT);
            loadChats();
        }
    }

    private void updateSelectedUsersText() {
        newChatTitleTv.setText((userEmailsList.size() == 0) ? getString(R.string.select_multiple_contacts) : "");

        for (int i = 0; i < userEmailsList.size(); i++) {
            newChatTitleTv.append(usersMap.get(userEmailsList.get(i)).getName());
            if (i < userEmailsList.size() - 1) {
                newChatTitleTv.append(", ");
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (loadChatsCalled) {
            return super.onCreateOptionsMenu(menu);
        } else {
            getMenuInflater().inflate(R.menu.chat_menu, menu);
            return super.onCreateOptionsMenu(menu);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (chatRefreshLayout.isRefreshing())
            return true;

        if (item.getItemId() == R.id.chat_done) {
            if (userEmailsList.size() > 1) {
                if (groupChatTitleEt.getText().toString().trim().length() == 0) {
                    displayAlert(getString(R.string.group_without_title), null, getString(R.string.no), getString(R.string.yes), null, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            getChatIfExist(userEmailsList);
                        }
                    });
                } else {
                    getChatIfExist(userEmailsList);
                }
            } else {
                Toast toast = Toast.makeText(this, R.string.alreat_2_contacts, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        }
        return true;
    }

    private void getChatIfExist(final ArrayList<String> userEmailsList) {
        chatRefreshLayout.setRefreshing(true);
        userEmailsList.add(currentUser.getEmail());
        Collections.sort(userEmailsList);

        if (userEmailsList.size() > 2) {
            createNewChat(userEmailsList);
        } else {
            mFireStore.collection(COLLECTIONS_CHATS)
                    .whereEqualTo("usersEmailsList", userEmailsList)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                List<DocumentSnapshot> documents = task.getResult().getDocuments();
                                if (documents.size() > 0) {
                                    currentChat = documents.get(0).toObject(Chat.class);
                                    loadChats();
                                } else {
                                    createNewChat(userEmailsList);
                                }
                            }
                        }
                    });
        }
    }

    private void createNewChat(ArrayList<String> userEmailsList) {
        final Chat chat = new Chat();
        chat.setMessagesList(new ArrayList<Message>());
        chat.setLatestMessageTimeInMillis(System.currentTimeMillis());
        chat.setUsersEmailsList(userEmailsList);
        if (userEmailsList.size() > 2) {
            chat.setTitle(groupChatTitleEt.getText().toString().trim().length() > 0 ? groupChatTitleEt.getText().toString().trim() : "");
        }

        CollectionReference chatRef = mFireStore.collection(COLLECTIONS_CHATS);
        chatRef.add(chat).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
            @Override
            public void onComplete(@NonNull Task<DocumentReference> task) {
                if (task.isSuccessful()) {
                    chat.setId(task.getResult().getId());
                    mFireStore.collection(COLLECTIONS_CHATS).document(task.getResult().getId()).update("id", task.getResult().getId()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            currentChat = chat;
                            loadChats();
                        }
                    });
                } else {
                    chatRefreshLayout.setRefreshing(false);
                    displayAlert(getString(R.string.unable_to_start_chat), null, getString(R.string.ok), null);
                }
            }
        });
    }

    private Chat currentChat;
    private boolean loadChatsCalled;
    private ChatMessagesAdapter messagesAdapter;

    private void loadChats() {
        loadChatsCalled = true;
        invalidateOptionsMenu();
        chatRefreshLayout.setRefreshing(false);

        if (currentChat.getUsersEmailsList().size() > 2 && currentChat.getTitle().length() > 0) {
            supportActionBar.setTitle(currentChat.getTitle());
        }

        String title;
        if (getIntent().getBooleanExtra(EXTRA_IS_NEW_CHAT, true) || currentChat.getUsersEmailsList().size() > 2) {
            StringBuilder titleBuilder = new StringBuilder();
            ArrayList<String> usersEmailsList = currentChat.getUsersEmailsList();
            for (int i = 0; i < usersEmailsList.size(); i++) {
                if (!usersEmailsList.get(i).equalsIgnoreCase(currentUser.getEmail())) {
                    if (titleBuilder.length() > 0)
                        titleBuilder.append(",");
                    titleBuilder.append(usersMap.get(usersEmailsList.get(i)).getName());
                }
            }
            title = titleBuilder.toString();
        } else {
            title = getIntent().getStringExtra(EXTRA_CHAT_TITLE);
        }

        supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.chat_subtitle) + "'>" + title + "</font>"));
        newChatTitleTv.setVisibility(View.GONE);
        groupChatTitleEt.setVisibility(View.GONE);
        groupChatTitleEtL.setVisibility(View.GONE);
        chatBottomRl.setVisibility(View.VISIBLE);
        chatRv.setAdapter(null);

        messagesAdapter = new ChatMessagesAdapter(getApplicationContext(), currentChat, currentChat.getMessagesList(), usersMap);
        chatRv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        chatRv.setAdapter(messagesAdapter);

        chatRv.smoothScrollToPosition(currentChat.getMessagesList().size());

        Glide.with(getApplicationContext())
                .load(currentUser.getProfileImageUrl() == null ? R.drawable.ic_profile : currentUser.getProfileImageUrl())
                .placeholder(R.drawable.ic_profile)
                .error(R.drawable.ic_profile)
                .centerCrop()
                .into(selfProfileIv);

        sendMessageTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!chatRefreshLayout.isRefreshing() && newMessageEt.getText().toString().trim().length() > 0) {
                    chatRefreshLayout.setRefreshing(true);

                    final Message message = new Message();
                    message.setMessageTimeInMillis(System.currentTimeMillis());
                    message.setMessage(newMessageEt.getText().toString().trim());
                    message.setUserEmail(currentUser.getEmail());
                    final ArrayList<Message> messagesList = currentChat.getMessagesList();
                    messagesList.add(message);

                    mFireStore.collection(COLLECTIONS_CHATS).document(currentChat.getId()).update("messagesList", messagesList, "latestMessageTimeInMillis", message.getMessageTimeInMillis()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                currentChat.setMessagesList(messagesList);
                                messagesAdapter.notifyDataSetChanged();
                                newMessageEt.setText("");
                                chatRv.smoothScrollToPosition(currentChat.getMessagesList().size());
                            } else {
                                messagesList.remove(message);
                                Toast.makeText(ChatActivity.this, R.string.failed_send_message, Toast.LENGTH_SHORT).show();
                            }
                            chatRefreshLayout.setRefreshing(false);
                        }
                    });
                }
            }
        });
        addSnapshotListener();
    }

    private ListenerRegistration chatListener;

    private void addSnapshotListener() {
        chatListener = mFireStore.collection(COLLECTIONS_CHATS)
                .whereEqualTo("id", currentChat.getId())
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException error) {
                        if (error == null && queryDocumentSnapshots != null) {
                            if (queryDocumentSnapshots.size() > 0) {
                                for (DocumentChange dc : queryDocumentSnapshots.getDocumentChanges()) {
                                    currentChat = dc.getDocument().toObject(Chat.class);
                                }
                            }
                            messagesAdapter.updateData(currentChat.getMessagesList());
                            messagesAdapter.notifyDataSetChanged();
                            chatRv.smoothScrollToPosition(currentChat.getMessagesList().size());
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (chatListener != null)
            chatListener.remove();
    }

    @Override
    public void onBackPressed() {
        if (chatRefreshLayout.isRefreshing())
            return;
        super.onBackPressed();
    }
}
