package com.myappcompany.snapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.adapters.ConversationsAdapter;
import com.myappcompany.snapp.model.Chat;
import com.myappcompany.snapp.model.Message;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static com.myappcompany.snapp.activities.ChatActivity.EXTRA_CHAT;
import static com.myappcompany.snapp.activities.ChatActivity.EXTRA_CHAT_TITLE;
import static com.myappcompany.snapp.activities.ChatActivity.EXTRA_IS_NEW_CHAT;
import static com.myappcompany.snapp.activities.ChatActivity.EXTRA_IS_NEW_GROUP;
import static com.myappcompany.snapp.activities.ChatActivity.EXTRA_USERS_MAP;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_CHATS;

public class ChatConversationsActivity extends BaseActivity {

    private SwipeRefreshLayout refreshLayout;
    private RecyclerView conversationsRv;
    private ArrayList<Chat> chatsList = new ArrayList<>();
    private ConversationsAdapter conversationsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_conversation);

        supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.chat_conversations_subtitle) + "'>" + getString(R.string.conversation) + "</font>"));
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        refreshLayout = findViewById(R.id.chat_refresh_layout);
        conversationsRv = findViewById(R.id.chat_conversations_rv);

        conversationsRv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                init();
            }
        });

        refreshLayout.setRefreshing(true);
        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_conversation_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (refreshLayout.isRefreshing())
            return true;

        if (item.getItemId() == R.id.chat_new) {
            Intent intentChat = new Intent(this, ChatActivity.class);
            intentChat.putExtra(EXTRA_IS_NEW_CHAT, true);
            intentChat.putExtra(EXTRA_IS_NEW_GROUP, false);
            intentChat.putExtra(EXTRA_USERS_MAP, usersMap);
            startActivity(intentChat);
        } else if (item.getItemId() == R.id.chat_new_group) {
            Intent intentChat = new Intent(this, ChatActivity.class);
            intentChat.putExtra(EXTRA_IS_NEW_GROUP, true);
            intentChat.putExtra(EXTRA_IS_NEW_CHAT, false);
            intentChat.putExtra(EXTRA_USERS_MAP, usersMap);
            startActivity(intentChat);
        }
        return true;
    }

    private void init() {
        mFireStore.collection(COLLECTIONS_CHATS)
                .whereArrayContains("usersEmailsList", FireBaseDataInstance.getInstance().getCurrentUser().getEmail())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            List<DocumentSnapshot> documents = task.getResult().getDocuments();
                            chatsList.clear();
                            if (documents.size() > 0) {
                                for (DocumentSnapshot snapshot : documents) {
                                    Chat chat = snapshot.toObject(Chat.class);
                                    chatsList.add(chat);
                                }
                            }
                        }
                        loadUsersAndData();
                    }
                });
    }

    private HashMap<String, Users> usersMap;

    private void loadUsersAndData() {
        FireBaseDataInstance.getInstance().readUsers(mFireStore, false, new FireBaseDataInstance.Delegate() {
            @Override
            public void onComplete(Object object) {
                ArrayList<Users> usersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();
                usersList.add(0, FireBaseDataInstance.getInstance().getCurrentUser());

                usersMap = new HashMap<>();
                for (int i = 0; i < usersList.size(); i++) {
                    usersMap.put(usersList.get(i).getEmail(), usersList.get(i));
                }

                Collections.sort(chatsList);

                for (int i = 0; i < chatsList.size(); i++) {
                    ArrayList<Message> messagesList = chatsList.get(i).getMessagesList();
                    Collections.sort(messagesList);
                    chatsList.get(i).setMessagesList(messagesList);
                }

                conversationsAdapter = new ConversationsAdapter(getApplicationContext(), chatsList, usersMap, new ConversationsAdapter.Delegate() {
                    @Override
                    public void onItemClicked(int position, String usersName, HashMap<String, Users> usersMap) {
                        if (refreshLayout.isRefreshing())
                            return;

                        Intent intentChat = new Intent(ChatConversationsActivity.this, ChatActivity.class);
                        intentChat.putExtra(EXTRA_IS_NEW_CHAT, false);
                        intentChat.putExtra(EXTRA_IS_NEW_GROUP, false);
                        intentChat.putExtra(EXTRA_CHAT, chatsList.get(position));
                        intentChat.putExtra(EXTRA_CHAT_TITLE, usersName);
                        intentChat.putExtra(EXTRA_USERS_MAP, usersMap);
                        startActivity(intentChat);
                    }
                });
                conversationsRv.setAdapter(conversationsAdapter);

                addSnapshotListener();
                refreshLayout.setRefreshing(false);
            }
        });
    }

    private ListenerRegistration chatConversationsListener;

    private void addSnapshotListener() {
        chatConversationsListener = mFireStore.collection(COLLECTIONS_CHATS)
                .whereArrayContains("usersEmailsList", FireBaseDataInstance.getInstance().getCurrentUser().getEmail())
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException error) {
                        if (error == null && queryDocumentSnapshots != null) {
                            chatsList.clear();
                            if (queryDocumentSnapshots.size() > 0) {
                                for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                                    Chat chat = snapshot.toObject(Chat.class);
                                    chatsList.add(chat);
                                }
                            }

                            Collections.sort(chatsList);

                            for (int i = 0; i < chatsList.size(); i++) {
                                ArrayList<Message> messagesList = chatsList.get(i).getMessagesList();
                                Collections.sort(messagesList);
                                chatsList.get(i).setMessagesList(messagesList);
                            }

                            conversationsAdapter.notifyDataSetChanged();
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (chatConversationsListener != null)
            chatConversationsListener.remove();
    }

    @Override
    public void onBackPressed() {
        if (refreshLayout.isRefreshing())
            return;

        super.onBackPressed();
    }
}
