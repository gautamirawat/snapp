package com.myappcompany.snapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.adapters.CommentsAdapter;
import com.myappcompany.snapp.model.Comment;
import com.myappcompany.snapp.model.Post;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_POSTS;

public class CommentActivity extends BaseActivity {

    private RecyclerView recyclerView;
    public static final String POST_OBJECT = "postObject";
    private CommentsAdapter commentsAdapter;
    private Post post;
    private ArrayList<Comment> commentsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);

        supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.comment_subtitle) + "'>" + getString(R.string.comment) + "</font>"));
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView = findViewById(R.id.comments_rv);
        recyclerView.setLayoutManager(linearLayoutManager);

        post = (Post) getIntent().getSerializableExtra(POST_OBJECT);
        commentsList = post.getCommentsList();
        Collections.sort(commentsList);

        FireBaseDataInstance.getInstance().readUsers(mFireStore, false, new FireBaseDataInstance.Delegate() {
            @Override
            public void onComplete(Object object) {
                ArrayList<Users> usersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();
                usersList.add(0, FireBaseDataInstance.getInstance().getCurrentUser());

                HashMap<String, Users> usersMap = new HashMap<>();
                for (int i = 0; i < usersList.size(); i++) {
                    usersMap.put(usersList.get(i).getEmail(), usersList.get(i));
                }

                commentsAdapter = new CommentsAdapter(getApplicationContext(), commentsList, usersMap);
                recyclerView.setAdapter(commentsAdapter);
            }
        });

        Glide.with(this)
                .load(FireBaseDataInstance.getInstance().getCurrentUser().getProfileImageUrl() == null ? R.drawable.ic_profile : FireBaseDataInstance.getInstance().getCurrentUser().getProfileImageUrl())
                .placeholder(R.drawable.ic_profile)
                .error(R.drawable.ic_profile)
                .centerCrop()
                .into((ImageView) findViewById(R.id.comment_self_profile_iv));

        final EditText commentEt = findViewById(R.id.comment_et);
        findViewById(R.id.post_tv).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (commentEt.getText().toString().trim().length() > 0) {
                    Comment comment = new Comment();
                    comment.setCommentTimeInMillis(System.currentTimeMillis());
                    comment.setComment(commentEt.getText().toString().trim());
                    comment.setUserEmail(FireBaseDataInstance.getInstance().getCurrentUser().getEmail());
                    commentsList.add(comment);

                    commentEt.setText("");

                    isCommentAdded = true;

                    mFireStore.collection(COLLECTIONS_POSTS).document(post.getId()).update("commentsList", commentsList).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            commentsAdapter.notifyDataSetChanged();
                        }
                    });
                }
            }
        });
    }

    private boolean isCommentAdded;

    @Override
    public void onBackPressed() {
        if (isCommentAdded) {
            Intent intent = new Intent();
            intent.putExtra("commentsList", commentsList);
            setResult(RESULT_OK, intent);
        }
        finish();
    }
}
