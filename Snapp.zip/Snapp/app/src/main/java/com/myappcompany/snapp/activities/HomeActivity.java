package com.myappcompany.snapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.hitomi.cmlibrary.CircleMenu;
import com.hitomi.cmlibrary.OnMenuSelectedListener;
import com.hitomi.cmlibrary.OnMenuStatusChangeListener;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.camera.CameraPreviewActivity;
import com.myappcompany.snapp.fragment.HomeFragment;
import com.myappcompany.snapp.fragment.NotificationFragment;
import com.myappcompany.snapp.fragment.SearchFragment;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import static com.myappcompany.snapp.activities.ProfileActivity.EXTRA_IS_CURRENT_USER;
import static com.myappcompany.snapp.activities.ProfileActivity.EXTRA_PROFILE_EMAIL;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_FROM_REGISTER;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_IS_GALLERY;

public class HomeActivity extends BaseActivity {

    private FloatingActionButton fabB;
    private CircleMenu circleMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        loadItemPostMenuClose();

        fabB = findViewById(R.id.fab_b);
        circleMenu = findViewById(R.id.circleMenu);

        fabB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fabB.setVisibility(View.GONE);
                circleMenu.setVisibility(View.VISIBLE);
                circleMenu.openMenu();
            }
        });

        circleMenu.setMainMenu(R.color.colorAccent, R.drawable.icon_menu, R.drawable.icon_cancel)
                .addSubMenu(getResources().getColor(R.color.circular_menu_home), R.drawable.ic_home)
                .addSubMenu(getResources().getColor(R.color.circular_menu_search), R.drawable.ic_search)
                .addSubMenu(getResources().getColor(R.color.circular_menu_add_post), R.drawable.ic_add)
                .addSubMenu(getResources().getColor(R.color.circular_menu_notification), R.drawable.ic_notification)
                .addSubMenu(getResources().getColor(R.color.circular_menu_profile), R.drawable.ic_profile)
                .setOnMenuSelectedListener(new OnMenuSelectedListener() {
                    @Override
                    public void onMenuSelected(int index) {
                        circularMenuSelected = true;
                        selectedIndex = index;
                    }
                });
        circleMenu.setOnMenuStatusChangeListener(new OnMenuStatusChangeListener() {
            @Override
            public void onMenuOpened() {

            }

            @Override
            public void onMenuClosed() {
                fabB.setVisibility(View.VISIBLE);
                circleMenu.setVisibility(View.GONE);
                if (circularMenuSelected) {
                    circularMenuSelected = false;
                    loadItemPostMenuClose();
                }
            }
        });
    }

    private int prevSelectedIndex = -1;
    private int selectedIndex = 0;
    private boolean circularMenuSelected;

    private HomeFragment homeFragment;
    private SearchFragment searchFragment;
    private NotificationFragment notificationFragment;

    private void loadItemPostMenuClose() {
        if (prevSelectedIndex == selectedIndex)
            return;

        switch (selectedIndex) {
            case 0:
                if (homeFragment == null)
                    homeFragment = new HomeFragment(mFireStore);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, homeFragment).commit();
                supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.circular_menu_home) + "'>" + getString(R.string.home) + "</font>"));
                prevSelectedIndex = selectedIndex;
                break;
            case 1:
                if (searchFragment == null)
                    searchFragment = new SearchFragment(mFireStore);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, searchFragment).commit();
                supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.circular_menu_search) + "'>" + getString(R.string.search) + "</font>"));
                prevSelectedIndex = selectedIndex;
                break;
            case 2:
                Intent intentCamera = new Intent(HomeActivity.this, CameraPreviewActivity.class);
                intentCamera.putExtra(EXTRA_FROM_REGISTER, false);
                intentCamera.putExtra(EXTRA_IS_GALLERY, false);
                startActivity(intentCamera);
                break;
            case 3:
                if (notificationFragment == null)
                    notificationFragment = new NotificationFragment(mFireStore);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, notificationFragment).commit();
                supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.circular_menu_notification) + "'>" + getString(R.string.notification) + "</font>"));
                prevSelectedIndex = selectedIndex;
                break;
            case 4:
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                intent.putExtra(EXTRA_PROFILE_EMAIL, FireBaseDataInstance.getInstance().getCurrentUser().getEmail());
                intent.putExtra(EXTRA_IS_CURRENT_USER, true);
                startActivityForResult(intent, RQ_PROFILE);
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (isRefreshing())
            return true;

        switch (item.getItemId()) {
            case R.id.home_action_chat:
                Intent intentChat = new Intent(this, ChatConversationsActivity.class);
                startActivity(intentChat);
                break;
            case R.id.home_action_map:
                Intent intentMap = new Intent(this, CurrentLocation.class);
                startActivity(intentMap);
                break;
        }
        return true;
    }

    private boolean backClickedTwice = false;

    private boolean isRefreshing() {
        return ((homeFragment != null && homeFragment.refreshLayout != null && homeFragment.refreshLayout.isRefreshing())
                || (searchFragment != null && searchFragment.refreshLayout != null && searchFragment.refreshLayout.isRefreshing()));
    }

    private static final int RQ_PROFILE = 111;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RQ_PROFILE && resultCode == RESULT_OK) {
            Intent intent = new Intent(getApplication(), SplashScreenActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (isRefreshing())
            return;

        if (backClickedTwice) {
            super.onBackPressed();
            return;
        }

        this.backClickedTwice = true;
        Toast toast = Toast.makeText(this, R.string.back_again_to_exit, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();


        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                backClickedTwice = false;
            }
        }, 2000);
    }
}
