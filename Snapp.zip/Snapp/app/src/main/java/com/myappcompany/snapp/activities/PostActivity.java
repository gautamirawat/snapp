package com.myappcompany.snapp.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.model.Post;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;

import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_FROM_REGISTER;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_IS_GALLERY;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_RESTART;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_POSTS;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.STORAGE_POSTS;

public class PostActivity extends BaseActivity {

    private Uri imageUri;
    private String myUrl = "";

    private ImageView image_added;
    private EditText description;
    private boolean fromRegister;
    private boolean isPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.circular_menu_add_post) + "'>Add New Post</font>"));
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        image_added = findViewById(R.id.image_added);
        description = findViewById(R.id.description);

        Bundle extras = getIntent().getExtras();
        isPhoto = extras.getBoolean("isPhoto");
        fromRegister = extras.getBoolean(EXTRA_FROM_REGISTER);
        boolean isGallery = extras.getBoolean(EXTRA_IS_GALLERY);

        Uri uri = null;
        String uri_to_post = extras.getString("URI_TO_POST");
        if (uri_to_post != null) {
            uri = Uri.parse(uri_to_post);
        }

        if (fromRegister) {
            if (!isGallery && uri != null) {
                CropImage.activity(uri)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(PostActivity.this);
            } else {
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(PostActivity.this);
            }
        } else {
            if (uri != null) {
                if (isPhoto) {
                    // Photo is available
                    CropImage.activity(uri)
                            .setGuidelines(CropImageView.Guidelines.ON)
                            .start(PostActivity.this);
                } else {
                    // Video is available
                    imageUri = uri;
                    Glide.with(this)
                            .load(imageUri)
                            .into(image_added);
                }
            } else {
                // No media available, ask for picking from library
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(PostActivity.this);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.post_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {
            case R.id.post_menu_b:
                uploadMedia();
                break;
        }
        return true;
    }

    private void uploadMedia() {
        if (imageUri != null) {
            displayProgressBar(getString(R.string.uploading));

            String fileExtension = isPhoto ? ".jpg" : ".mp4";
            StorageReference storageReference = FirebaseStorage.getInstance().getReference(STORAGE_POSTS + File.separator + FireBaseDataInstance.getInstance().getCurrentUser().getEmail());
            final StorageReference fileReference = storageReference.child(System.currentTimeMillis() + fileExtension);

            StorageTask uploadTask = fileReference.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if (!task.isComplete()) {
                        throw task.getException();
                    }

                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = (Uri) task.getResult();
                        myUrl = downloadUri.toString();

                        Post post = new Post();
                        post.setDescription(description.getText().toString().trim());
                        post.setPostImage(myUrl);
                        post.setPostEmailId(FirebaseAuth.getInstance().getCurrentUser().getEmail());
                        post.setPublisher(FirebaseAuth.getInstance().getCurrentUser().getUid());
                        post.setTimeInMillis(System.currentTimeMillis());

                        CollectionReference usersRef = mFireStore.collection(COLLECTIONS_POSTS);
                        usersRef.add(post).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentReference> task) {
                                dismissProgress();
                                if (task.isSuccessful()) {

                                    mFireStore.collection(COLLECTIONS_POSTS).document(task.getResult().getId()).update("id", task.getResult().getId()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            Toast.makeText(PostActivity.this, R.string.posted, Toast.LENGTH_LONG).show();

                                            setResult(RESULT_OK);
                                            finish();
                                        }
                                    });
                                } else {
                                    displayAlert(getString(R.string.unable_to_post), null, getString(R.string.ok), null);
                                }
                            }
                        });
                    } else {
                        dismissProgress();
                        displayAlert(getString(R.string.unable_to_post), null, getString(R.string.ok), null);
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dismissProgress();
                    displayAlert(getString(R.string.unable_to_post) + "\n\n" + e.getMessage(), null, getString(R.string.ok), null);
                }
            });
        } else {
            displayAlert(getString(R.string.unable_to_post), null, getString(R.string.ok), null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            imageUri = result.getUri();
            image_added.setImageURI(imageUri);

            if (fromRegister) {
                Intent intent = new Intent();
                intent.putExtra("imageUri", imageUri.toString());
                intent.putExtra(EXTRA_RESTART, false);
                setResult(RESULT_OK, intent);
                finish();
            }
        } else {
            Toast.makeText(this, R.string.gone_wrong, Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
