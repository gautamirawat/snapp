package com.myappcompany.snapp.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.adapters.PostAdapter;
import com.myappcompany.snapp.camera.CameraPreviewActivity;
import com.myappcompany.snapp.model.Comment;
import com.myappcompany.snapp.model.Post;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.google.firebase.firestore.Query.Direction.DESCENDING;
import static com.myappcompany.snapp.activities.CommentActivity.POST_OBJECT;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_FROM_REGISTER;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_IS_GALLERY;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_RESTART;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_POSTS;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_USERS;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.STORAGE_IMAGES;

public class ProfileActivity extends BaseActivity {

    public static final String EXTRA_PROFILE_EMAIL = "profileEmail";
    public static final String EXTRA_IS_CURRENT_USER = "isCurrentUser";
    private TextView nameTv;
    private TextView statusTv;
    private ImageView profileIv;
    private static int RQ_IMAGE = 103;
    private boolean isCurrentUser;
    private String stringExtraEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.circular_menu_profile) + "'>" + getString(R.string.profile) + "</font>"));
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_PROFILE_EMAIL)) {
            stringExtraEmail = intent.getStringExtra(EXTRA_PROFILE_EMAIL);
        } else {
            Toast.makeText(this, R.string.invalid_profile, Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        nameTv = findViewById(R.id.profile_name_tv);
        statusTv = findViewById(R.id.profile_status_tv);
        Button saveB = findViewById(R.id.profile_save_b);
        profileIv = findViewById(R.id.profile_iv);

        if (intent.getBooleanExtra(EXTRA_IS_CURRENT_USER, false)) {
            isCurrentUser = true;
            saveB.setVisibility(View.VISIBLE);
            supportActionBar.setSubtitle(Html.fromHtml("<font color='#" + getResources().getColor(R.color.circular_menu_profile) + "'>" + getString(R.string.your_profile) + "</font>"));
        } else {
            isCurrentUser = false;
            nameTv.setEnabled(false);
            statusTv.setEnabled(false);
            saveB.setVisibility(View.GONE);
            profileIv.setEnabled(false);
        }
        invalidateOptionsMenu();

        saveB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String name = nameTv.getText().toString().trim();
                final String status = statusTv.getText().toString().trim();

                if (name.length() == 0) {
                    displayAlert(getString(R.string.name_empty), null, getString(R.string.ok), null);
                    return;
                }

                if (profileImageUri == null) {
                    displayProgressBar(getString(R.string.updating_profile));
                    mFireStore.collection(COLLECTIONS_USERS).document(FireBaseDataInstance.getInstance().getCurrentUserDocumentId()).update("name", name, "status", status).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            dismissProgress();
                            displayAlert(getString(R.string.profile_updated), null, getString(R.string.ok), null);
                        }
                    });
                } else {
                    uploadMedia();
                }
            }
        });

        profileIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder b = new AlertDialog.Builder(ProfileActivity.this);
                b.setTitle(R.string.choose_option);
                String[] types = {getString(R.string.camera), getString(R.string.gallery), getString(R.string.delete_photo)};
                b.setItems(types, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        switch (which) {
                            case 0:
                                Intent intentCamera = new Intent(ProfileActivity.this, CameraPreviewActivity.class);
                                intentCamera.putExtra(EXTRA_FROM_REGISTER, true);
                                intentCamera.putExtra(EXTRA_IS_GALLERY, false);
                                startActivityForResult(intentCamera, RQ_IMAGE);
                                break;
                            case 1:
                                Intent intentGallery = new Intent(ProfileActivity.this, PostActivity.class);
                                intentGallery.putExtra(EXTRA_FROM_REGISTER, true);
                                intentGallery.putExtra(EXTRA_IS_GALLERY, true);
                                startActivityForResult(intentGallery, RQ_IMAGE);
                                break;
                            case 3:
                                profileImageUri = null;
                                Glide.with(getApplicationContext())
                                        .load("")
                                        .placeholder(R.drawable.ic_profile)
                                        .error(R.drawable.ic_profile)
                                        .centerCrop()
                                        .into(profileIv);
                                break;
                        }
                    }

                });

                b.show();
            }
        });

        refreshLayout = findViewById(R.id.refresh_layout);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getProfile(stringExtraEmail);
            }
        });

        getProfile(stringExtraEmail);
        refreshLayout.setRefreshing(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (isCurrentUser) {
            getMenuInflater().inflate(R.menu.profile_menu, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (refreshLayout.isRefreshing())
            return true;

        switch (item.getItemId()) {
            case R.id.profile_logout:
                displayAlert(getString(R.string.user_logout), null, getString(R.string.cancel), getString(R.string.ok), null, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        displayProgressBar(getString(R.string.logging_out));
                        FirebaseAuth.getInstance().addAuthStateListener(new FirebaseAuth.AuthStateListener() {
                            @Override
                            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                                dismissProgress();
                                FirebaseAuth.getInstance().removeAuthStateListener(this);
                                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                if (user == null) {
                                    setResult(RESULT_OK);
                                    finish();
                                }
                            }
                        });
                        FirebaseAuth.getInstance().signOut();
                    }
                });
                break;
            case R.id.profile_delete_user:
                displayAlert(getString(R.string.user_delete_account), null, getString(R.string.cancel), getString(R.string.ok), null, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Need to re-authenticate and then call delete account on success.
                        Toast.makeText(ProfileActivity.this, "Yet to implement!", Toast.LENGTH_SHORT).show();
                    }
                });
                break;
        }
        return true;
    }

    private SwipeRefreshLayout refreshLayout;
    private Users currentUser;

    private void getProfile(String stringExtra) {
        mFireStore.collection(COLLECTIONS_USERS).whereEqualTo("email", stringExtra)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            List<DocumentSnapshot> documents = task.getResult().getDocuments();
                            if (documents.size() > 0) {
                                currentUser = documents.get(0).toObject(Users.class);
                                loadProfile();
                            }
                        }
                        readPosts();
                    }
                });
    }

    private void loadProfile() {
        nameTv.setText(currentUser.getName());
        statusTv.setText(currentUser.getStatus());
        Glide.with(getApplicationContext())
                .load(currentUser.getProfileImageUrl())
                .placeholder(R.drawable.ic_profile)
                .error(R.drawable.ic_profile)
                .centerCrop()
                .into(profileIv);
    }

    private PostAdapter postAdapter;
    private ArrayList<Post> postLists = new ArrayList<>();
    private RecyclerView recyclerView;

    private void readPosts() {
        recyclerView = findViewById(R.id.profile_posts_rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        mFireStore.collection(COLLECTIONS_POSTS).orderBy("timeInMillis", DESCENDING)
                .whereEqualTo("postEmailId", stringExtraEmail)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            List<DocumentSnapshot> documents = task.getResult().getDocuments();
                            if (documents.size() > 0) {
                                postLists.clear();
                                for (DocumentSnapshot snapshot : documents) {
                                    Post post = snapshot.toObject(Post.class);
                                    postLists.add(post);
                                }

                                ArrayList<Users> usersList = new ArrayList<>();
                                if (!isCurrentUser)
                                    usersList.add(0, FireBaseDataInstance.getInstance().getCurrentUser());
                                usersList.add(currentUser);
                                postAdapter = new PostAdapter(getApplicationContext(), mFireStore, postLists, usersList, delegate);
                                recyclerView.setAdapter(postAdapter);
                            }
                        }
                        findViewById(R.id.no_posts_tv).setVisibility((postLists.size() == 0) ? View.VISIBLE : View.GONE);
                        refreshLayout.setRefreshing(false);
                    }
                });
    }

    private int recentPostCommentsPosition;
    private int RQ_COMMENTS = 112;

    private final PostAdapter.PostAdapterDelegate delegate = new PostAdapter.PostAdapterDelegate() {
        @Override
        public void onCommentsClicked(int position) {
            if (refreshLayout.isRefreshing())
                return;

            recentPostCommentsPosition = position;
            Intent intent = new Intent(ProfileActivity.this, CommentActivity.class);
            intent.putExtra(POST_OBJECT, postLists.get(position));
            startActivityForResult(intent, RQ_COMMENTS);
        }

        @Override
        public void onProfileClicked(int position) {
            // Do nothing as it is self profile.
        }
    };

    private Uri profileImageUri;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RQ_IMAGE && resultCode == RESULT_OK) {
            if (data.getBooleanExtra(EXTRA_RESTART, false)) {
                Intent intent = new Intent(ProfileActivity.this, CameraPreviewActivity.class);
                intent.putExtra(EXTRA_FROM_REGISTER, data.getBooleanExtra(EXTRA_FROM_REGISTER, false));
                intent.putExtra(EXTRA_IS_GALLERY, data.getBooleanExtra(EXTRA_IS_GALLERY, false));
                startActivityForResult(intent, RQ_IMAGE);
            } else {
                profileImageUri = Uri.parse(data.getExtras().getString("imageUri"));
                Glide.with(getApplicationContext())
                        .load(profileImageUri)
                        .placeholder(R.drawable.ic_profile)
                        .error(R.drawable.ic_profile)
                        .centerCrop()
                        .into(profileIv);
            }
        }

        if (requestCode == RQ_COMMENTS && resultCode == RESULT_OK) {
            ArrayList<Comment> commentsList = (ArrayList<Comment>) data.getSerializableExtra("commentsList");
            postLists.get(recentPostCommentsPosition).setCommentsList(commentsList);
            postAdapter.notifyDataSetChanged();
        }
    }

    private StorageTask uploadTask;
    private StorageReference storageReference;

    private void uploadMedia() {
        if (profileImageUri != null) {
            displayProgressBar(getString(R.string.uploading_profile_image));

            storageReference = FirebaseStorage.getInstance().getReference(STORAGE_IMAGES + File.separator + FireBaseDataInstance.getInstance().getCurrentUser().getEmail());

            final StorageReference fileReference = storageReference.child(System.currentTimeMillis() + ".jpg");

            uploadTask = fileReference.putFile(profileImageUri);
            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if (!task.isComplete()) {
                        throw task.getException();
                    }

                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    dismissProgress();
                    if (task.isSuccessful()) {
                        Uri downloadUri = (Uri) task.getResult();
                        String myProfileImageUrl = downloadUri.toString();

                        String name = nameTv.getText().toString().trim();
                        String status = statusTv.getText().toString().trim();

                        displayProgressBar(getString(R.string.updating_profile));
                        mFireStore.collection(COLLECTIONS_USERS).document(FireBaseDataInstance.getInstance().getCurrentUserDocumentId()).update(
                                "name", name,
                                "status", status,
                                "profileImageUrl", myProfileImageUrl).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                dismissProgress();
                                displayAlert(getString(R.string.profile_updated), null, getString(R.string.ok), null);
                            }
                        });
                    } else {
                        displayAlert(getString(R.string.unable_to_upload), null, getString(R.string.ok), null);
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dismissProgress();
                    displayAlert(getString(R.string.unable_to_upload), null, getString(R.string.ok), null);
                }
            });
        } else {
            displayAlert(getString(R.string.unable_to_upload), null, getString(R.string.ok), null);
        }
    }

    @Override
    public void onBackPressed() {
        if (refreshLayout.isRefreshing())
            return;
        super.onBackPressed();
    }
}
