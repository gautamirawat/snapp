package com.myappcompany.snapp.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.camera.CameraPreviewActivity;
import com.myappcompany.snapp.model.Users;

import java.io.File;
import java.util.ArrayList;

import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_FROM_REGISTER;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_IS_GALLERY;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_RESTART;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_USERS;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.STORAGE_IMAGES;

public class RegisterActivity extends BaseActivity {

    private EditText mEmail;
    private EditText mName;
    private EditText mPassword;
    private EditText mPasswordConfirm;
    private ImageView profileIv;
    private FirebaseAuth mAuth;
    private static int RQ_IMAGE = 102;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        supportActionBar.hide();

        mFireStore = FirebaseFirestore.getInstance();

        mAuth = FirebaseAuth.getInstance();
        mName = findViewById(R.id.name);
        Button mRegistration = findViewById(R.id.registration);
        mEmail = findViewById(R.id.email);
        mPassword = findViewById(R.id.password);
        mPasswordConfirm = findViewById(R.id.confirm_password);
        profileIv = findViewById(R.id.profile_iv);

        profileIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder b = new AlertDialog.Builder(RegisterActivity.this);
                b.setTitle(R.string.choose_option);
                String[] types = {getString(R.string.camera), getString(R.string.gallery)};
                b.setItems(types, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        switch (which) {
                            case 0:
                                Intent intentCamera = new Intent(RegisterActivity.this, CameraPreviewActivity.class);
                                intentCamera.putExtra(EXTRA_FROM_REGISTER, true);
                                intentCamera.putExtra(EXTRA_IS_GALLERY, false);
                                startActivityForResult(intentCamera, RQ_IMAGE);
                                break;
                            case 1:
                                Intent intentGallery = new Intent(RegisterActivity.this, PostActivity.class);
                                intentGallery.putExtra(EXTRA_FROM_REGISTER, true);
                                intentGallery.putExtra(EXTRA_IS_GALLERY, true);
                                startActivityForResult(intentGallery, RQ_IMAGE);
                                break;
                        }
                    }

                });

                b.show();
            }
        });

        mRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = mName.getText().toString().trim();
                final String email = mEmail.getText().toString().trim();
                final String password = mPassword.getText().toString();

                if (name.length() == 0 && email.length() == 0) {
                    displayAlert(getString(R.string.enter_name_email), null, getString(R.string.ok), null);
                    return;
                } else if (password.length() == 0 || mPasswordConfirm.getText().toString().length() == 0) {
                    displayAlert(getString(R.string.enter_password), null, getString(R.string.ok), null);
                    return;
                } else if (password.length() <= 7) {
                    displayAlert(getString(R.string.password_length_7), null, getString(R.string.ok), null);
                    return;
                } else if (!password.equals(mPasswordConfirm.getText().toString())) {
                    displayAlert(getString(R.string.password_doesnt_match), null, getString(R.string.ok), null);
                    return;
                }

                displayProgressBar(getString(R.string.registering));
                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        dismissProgress();
                        if (!task.isSuccessful()) {
                            displayAlert(getString(R.string.register_error), null, getString(R.string.ok), null);
                        } else {
                            if (profileImageUri != null) {
                                uploadMedia();
                            } else {
                                String userId = mAuth.getCurrentUser().getUid();

                                Users user = new Users();
                                user.setId(userId);
                                user.setEmail(email);
                                user.setName(name);
                                user.setFollowing(new ArrayList<String>());
                                user.setProfileImageUrl("");
                                CollectionReference usersRef = mFireStore.collection(COLLECTIONS_USERS);
                                usersRef.add(user);

                                setResult(RESULT_OK);
                                finish();
                            }
                        }
                    }
                });
            }
        });
    }

    private Uri profileImageUri;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RQ_IMAGE && resultCode == RESULT_OK) {
            if (data.getBooleanExtra(EXTRA_RESTART, false)) {
                Intent intent = new Intent(RegisterActivity.this, CameraPreviewActivity.class);
                intent.putExtra(EXTRA_FROM_REGISTER, data.getBooleanExtra(EXTRA_FROM_REGISTER, false));
                intent.putExtra(EXTRA_IS_GALLERY, data.getBooleanExtra(EXTRA_IS_GALLERY, false));
                startActivityForResult(intent, RQ_IMAGE);
            } else {
                profileImageUri = Uri.parse(data.getExtras().getString("imageUri"));
                profileIv.setImageURI(profileImageUri);
                findViewById(R.id.profile_tv).setVisibility(View.GONE);
            }
        }
    }

    private void uploadMedia() {
        if (profileImageUri != null) {
            displayProgressBar(getString(R.string.uploading_profile_image));

            StorageReference storageReference = FirebaseStorage.getInstance().getReference(STORAGE_IMAGES + File.separator + mEmail.getText().toString().trim());
            final StorageReference fileReference = storageReference.child(System.currentTimeMillis() + ".jpg");

            StorageTask uploadTask = fileReference.putFile(profileImageUri);
            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if (!task.isComplete()) {
                        throw task.getException();
                    }

                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    dismissProgress();
                    if (task.isSuccessful()) {
                        Uri downloadUri = (Uri) task.getResult();
                        String myProfileImageUrl = downloadUri.toString();

                        String userId = mAuth.getCurrentUser().getUid();

                        Users user = new Users();
                        user.setId(userId);
                        user.setEmail(mEmail.getText().toString().trim());
                        user.setName(mName.getText().toString().trim());
                        user.setFollowing(new ArrayList<String>());
                        user.setProfileImageUrl(myProfileImageUrl);
                        CollectionReference usersRef = mFireStore.collection(COLLECTIONS_USERS);
                        usersRef.add(user);

                        setResult(RESULT_OK);
                        finish();
                    } else {
                        displayAlert(getString(R.string.unable_to_upload), null, getString(R.string.ok), null);
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dismissProgress();
                    displayAlert(getString(R.string.unable_to_upload), null, getString(R.string.ok), null);
                }
            });
        } else {
            displayAlert(getString(R.string.unable_to_upload), null, getString(R.string.ok), null);
        }
    }
}
