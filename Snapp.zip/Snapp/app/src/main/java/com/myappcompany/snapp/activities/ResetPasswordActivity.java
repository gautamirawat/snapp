package com.myappcompany.snapp.activities;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.myappcompany.snapp.R;

public class ResetPasswordActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        supportActionBar.hide();

        final EditText emailEt = findViewById(R.id.email);

        findViewById(R.id.send_email).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (emailEt.getText().toString().trim().length() > 0) {
                    displayProgressBar("Sending reset password link to your registered email...");
                    FirebaseAuth.getInstance().sendPasswordResetEmail(emailEt.getText().toString().trim()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            dismissProgress();
                            if (task.isSuccessful()) {
                                displayAlert("Password reset link sent successfully to your registered email.", null, getString(R.string.ok), null, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        finish();
                                    }
                                }, null);
                            } else {
                                if (task.getException() != null) {
                                    String exceptionStr = task.getException().getLocalizedMessage();
                                    displayAlert(exceptionStr + "\n\nFailed to send password reset link to your email.", null, getString(R.string.ok), null);
                                } else {
                                    displayAlert("Failed to send password reset link to your email. Kindly try again.", null, getString(R.string.ok), null);
                                }
                            }
                        }
                    });
                } else {
                    displayAlert("Please enter your registered email and try again.", null, getString(R.string.ok), null);
                }
            }
        });
    }
}
