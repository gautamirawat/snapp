package com.myappcompany.snapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.myappcompany.snapp.R;

public class SplashScreenActivity extends BaseActivity {

    private Handler handler;
    private static final int SPLASH_DELAY = 2000;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        supportActionBar.hide();

        handler = new Handler();

        TextView appNameTv = findViewById(R.id.splash_app_name_tv);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);
        alphaAnimation.setDuration(SPLASH_DELAY);
        appNameTv.setAnimation(alphaAnimation);
        appNameTv.animate();
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            Intent intent = new Intent(getApplication(), mAuth.getCurrentUser() != null ? HomeActivity.class : LoginActivity.class);
            startActivity(intent);
            finish();
        }
    };

    @Override
    protected void onPause() {
        super.onPause();
        if (handler != null) {
            handler.removeCallbacks(runnable);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.postDelayed(runnable, SPLASH_DELAY);
    }
}
