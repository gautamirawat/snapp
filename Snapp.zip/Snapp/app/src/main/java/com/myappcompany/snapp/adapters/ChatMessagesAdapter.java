package com.myappcompany.snapp.adapters;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.myappcompany.snapp.R;
import com.myappcompany.snapp.model.Chat;
import com.myappcompany.snapp.model.Message;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.HashMap;

public class ChatMessagesAdapter extends RecyclerView.Adapter<ChatMessagesAdapter.ViewHolder> {

    private Context mContext;
    private Chat currentChat;
    private ArrayList<Message> messagesList;
    private HashMap<String, Users> usersMap;
    private Users currentUser;

    public ChatMessagesAdapter(Context mContext, Chat currentChat, ArrayList<Message> messagesList, HashMap<String, Users> usersMap) {
        this.mContext = mContext;
        this.currentChat = currentChat;
        this.messagesList = messagesList;
        this.usersMap = usersMap;
        this.currentUser = FireBaseDataInstance.getInstance().getCurrentUser();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.chat_message_item, parent, false);
        return new ChatMessagesAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Message message = messagesList.get(position);

        if (currentChat.getUsersEmailsList().size() > 2) {
            holder.userNameTv.setText(usersMap.get(message.getUserEmail()).getName());
            holder.userNameTv.setVisibility(View.VISIBLE);
        } else {
            holder.userNameTv.setVisibility(View.GONE);
        }
        holder.messageTv.setText(message.getMessage());

        if (currentUser.getEmail().equalsIgnoreCase(message.getUserEmail())) {
            holder.messageLl.setGravity(Gravity.END);
            holder.userNameTv.setGravity(Gravity.END);
            holder.messageTv.setGravity(Gravity.END);
        } else {
            holder.messageLl.setGravity(Gravity.START);
            holder.userNameTv.setGravity(Gravity.START);
            holder.messageTv.setGravity(Gravity.START);
        }
    }

    @Override
    public int getItemCount() {
        return messagesList.size();
    }

    public void updateData(ArrayList<Message> messagesList) {
        this.messagesList = messagesList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout messageLl;
        private TextView userNameTv;
        private TextView messageTv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            messageLl = itemView.findViewById(R.id.chat_message_ll);
            userNameTv = itemView.findViewById(R.id.username);
            messageTv = itemView.findViewById(R.id.message);
        }
    }
}
