package com.myappcompany.snapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.model.Comment;
import com.myappcompany.snapp.model.Users;

import org.ocpsoft.prettytime.PrettyTime;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.ViewHolder> {

    private Context mContext;
    private ArrayList<Comment> commentsList;
    private HashMap<String, Users> usersMap;
    private PrettyTime prettyTime;

    public CommentsAdapter(Context mContext, ArrayList<Comment> commentsList, HashMap<String, Users> usersMap) {
        this.mContext = mContext;
        this.commentsList = commentsList;
        this.usersMap = usersMap;
        prettyTime = new PrettyTime();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.comment_item, parent, false);
        return new CommentsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Comment comment = commentsList.get(position);

        holder.userCommentTv.setText(comment.getComment());
        holder.userNameTv.setText(usersMap.get(comment.getUserEmail()).getName());
        Glide.with(mContext)
                .load(usersMap.get(comment.getUserEmail()).getProfileImageUrl() == null ? R.drawable.ic_profile : usersMap.get(comment.getUserEmail()).getProfileImageUrl())
                .placeholder(R.drawable.ic_profile)
                .error(R.drawable.ic_profile)
                .centerCrop()
                .into(holder.imageProfileIv);
        holder.timeTv.setText(prettyTime.format(new Date(comment.getCommentTimeInMillis())));
        holder.commentDividerV.setVisibility((position == commentsList.size() - 1) ? View.INVISIBLE : View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return commentsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView imageProfileIv;
        private TextView userNameTv;
        private TextView userCommentTv;
        private TextView timeTv;
        private View commentDividerV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageProfileIv = itemView.findViewById(R.id.image_profile);
            userNameTv = itemView.findViewById(R.id.username_tv);
            userCommentTv = itemView.findViewById(R.id.user_comment_tv);
            timeTv = itemView.findViewById(R.id.time_tv);
            commentDividerV = itemView.findViewById(R.id.comment_divider_v);
        }
    }
}
