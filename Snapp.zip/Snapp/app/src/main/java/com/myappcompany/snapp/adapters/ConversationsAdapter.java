package com.myappcompany.snapp.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.model.Chat;
import com.myappcompany.snapp.model.Message;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.HashMap;

public class ConversationsAdapter extends RecyclerView.Adapter<ConversationsAdapter.ViewHolder> {

    private Context mContext;
    private ArrayList<Chat> chatList;
    private HashMap<String, Users> usersMap;
    private Delegate delegate;
    private Users currentUser;

    public ConversationsAdapter(Context mContext, ArrayList<Chat> chatList, HashMap<String, Users> usersMap, Delegate delegate) {
        this.mContext = mContext;
        this.chatList = chatList;
        this.usersMap = usersMap;
        this.delegate = delegate;
        currentUser = FireBaseDataInstance.getInstance().getCurrentUser();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.conversations_item, parent, false);
        return new ConversationsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Chat chat = chatList.get(position);

        StringBuffer userNamesToDisplay = new StringBuffer();
        ArrayList<String> usersEmailsList = chat.getUsersEmailsList();

        if (usersEmailsList.size() > 2 && chat.getTitle().length() > 0) {
            userNamesToDisplay.append(chat.getTitle());
        } else {
            for (int i = 0; i < usersEmailsList.size(); i++) {
                if (!usersEmailsList.get(i).equalsIgnoreCase(currentUser.getEmail())) {
                    if (userNamesToDisplay.length() > 0)
                        userNamesToDisplay.append(",");
                    userNamesToDisplay.append(usersMap.get(usersEmailsList.get(i)).getName());
                }
            }
        }
        holder.userNamesTv.setText(userNamesToDisplay);

        ArrayList<Message> messagesList = chat.getMessagesList();
        holder.mostRecentMessageTv.setText((messagesList.size() > 0) ? messagesList.get(messagesList.size() - 1).getMessage() : "");

        if (usersEmailsList.size() > 2) {
            Glide.with(mContext)
                    .load(R.drawable.ic_profile)
                    .placeholder(R.drawable.ic_profile)
                    .error(R.drawable.ic_profile)
                    .centerCrop()
                    .into(holder.imageProfileIv);
        } else {
            String profileImageUrl = "";
            for (int i = 0; i < usersEmailsList.size(); i++) {
                if (!usersEmailsList.get(i).equalsIgnoreCase(currentUser.getEmail())) {
                    profileImageUrl = usersMap.get(usersEmailsList.get(i)).getProfileImageUrl();
                    break;
                }
            }

            Glide.with(mContext)
                    .load(profileImageUrl)
                    .placeholder(R.drawable.ic_profile)
                    .error(R.drawable.ic_profile)
                    .centerCrop()
                    .into(holder.imageProfileIv);
        }
    }

    private HashMap<String, Bitmap> userImagesMap = new HashMap<>();

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView imageProfileIv;
        private TextView userNamesTv;
        private TextView mostRecentMessageTv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (delegate != null)
                        delegate.onItemClicked(getAdapterPosition(), userNamesTv.getText().toString(), usersMap);
                }
            });

            imageProfileIv = itemView.findViewById(R.id.image_profile);
            userNamesTv = itemView.findViewById(R.id.usernames_tv);
            mostRecentMessageTv = itemView.findViewById(R.id.most_recent_message_tv);
        }
    }

    public interface Delegate {
        void onItemClicked(int position, String usersName, HashMap<String, Users> usersMap);
    }
}
