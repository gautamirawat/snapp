package com.myappcompany.snapp.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amrdeveloper.reactbutton.ReactButton;
import com.amrdeveloper.reactbutton.Reaction;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.model.Like;
import com.myappcompany.snapp.model.Post;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import org.ocpsoft.prettytime.PrettyTime;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_POSTS;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    public Context mContext;
    private FirebaseFirestore mFireStore;
    public List<Post> postList;
    private ArrayList<Users> usersList;
    private PostAdapterDelegate delegate;
    private PrettyTime prettyTime;

    public PostAdapter(Context mContext, FirebaseFirestore mFireStore, List<Post> postList, ArrayList<Users> usersList, PostAdapterDelegate delegate) {
        this.mContext = mContext;
        this.mFireStore = mFireStore;
        this.postList = postList;
        this.usersList = usersList;
        this.delegate = delegate;
        prettyTime = new PrettyTime();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.post_item, parent, false);
        return new PostAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Post post = postList.get(position);
        Users postUser = getPostUser(post.getPostEmailId());

        Glide.with(mContext)
                .load(postUser.getProfileImageUrl() == null ? R.drawable.ic_profile : postUser.getProfileImageUrl())
                .placeholder(R.drawable.ic_profile)
                .error(R.drawable.ic_profile)
                .fitCenter()
                .into(holder.imageProfileIv);
        holder.usernameTv.setText(postUser.getName());
        Glide.with(mContext)
                .load(post.getPostImage())
                .fitCenter()
                .centerCrop()
                .into(holder.postImageIv);
        holder.commentTv.setText(String.valueOf(post.getCommentsList().size()));
        ArrayList<Like> likesList = post.getLikesList();
        holder.likeTv.setText(String.valueOf(likesList.size()));
        holder.descriptionTv.setText(post.getDescription());

        String likeType = "default";
        int emailLikeIndex = 0;
        for (emailLikeIndex = 0; emailLikeIndex < likesList.size(); emailLikeIndex++) {
            if (likesList.get(emailLikeIndex).getUserEmail().equals(usersList.get(0).getEmail())) {
                likeType = likesList.get(emailLikeIndex).getLikeType();
                if (likeType == null)
                    likeType = "default";
                break;
            }
        }
        holder.reactButton.setCurrentReaction(new Reaction(likeType.equals("default") ? "LIKE" : likeType, getReactColor(likeType), getReactIconId(likeType)));
        holder.reactButton.setTag(likeType.equals("default") ? -1 : emailLikeIndex);

        holder.timeTv.setText(prettyTime.format(new Date(post.getTimeInMillis())));
    }

    private Users getPostUser(String postEmail) {
        for (int i = 0; i < usersList.size(); i++) {
            if (usersList.get(i).getEmail().equals(postEmail)) {
                return usersList.get(i);
            }
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageProfileIv;
        public TextView usernameTv;
        public TextView timeTv;
        public ImageView postImageIv;
        public TextView commentTv;
        public TextView likeTv;
        public TextView descriptionTv;
        public ReactButton reactButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageProfileIv = itemView.findViewById(R.id.image_profile);
            usernameTv = itemView.findViewById(R.id.username);
            timeTv = itemView.findViewById(R.id.time_tv);
            postImageIv = itemView.findViewById(R.id.post_image);
            commentTv = itemView.findViewById(R.id.comment_tv);
            likeTv = itemView.findViewById(R.id.like_tv);
            descriptionTv = itemView.findViewById(R.id.description);
            reactButton = itemView.findViewById(R.id.react_button);

            commentTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (delegate != null)
                        delegate.onCommentsClicked(getAdapterPosition());
                }
            });

            likeTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });

            timeTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (delegate != null)
                        delegate.onProfileClicked(getAdapterPosition());
                }
            });
            usernameTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (delegate != null)
                        delegate.onProfileClicked(getAdapterPosition());
                }
            });
            imageProfileIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (delegate != null)
                        delegate.onProfileClicked(getAdapterPosition());
                }
            });

            reactButton.setReactClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    updateLikeReaction(getAdapterPosition(), (Integer) view.getTag(), reactButton.getCurrentReaction(), reactButton.isDefaultReaction());
                }
            });
            reactButton.setReactDismissListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    updateLikeReaction(getAdapterPosition(), (Integer) view.getTag(), reactButton.getCurrentReaction(), reactButton.isDefaultReaction());
                    return false;
                }
            });
        }
    }

    private void updateLikeReaction(final int position, int emailLikeIndex, Reaction reaction, boolean defaultReaction) {
        try {
            ArrayList<Like> likesList = postList.get(position).getLikesList();
            if (emailLikeIndex == -1) {
                Like like = new Like();
                like.setLikeTimeInMillis(System.currentTimeMillis());
                like.setLikeType(reaction.getReactText());
                like.setUserEmail(FireBaseDataInstance.getInstance().getCurrentUser().getEmail());
                likesList.add(like);
            } else {
                Like like = likesList.get(emailLikeIndex);
                likesList.remove(like);
                if (!reaction.getReactText().equalsIgnoreCase("LIKE")) {
                    like.setLikeType(reaction.getReactText());
                    like.setLikeTimeInMillis(System.currentTimeMillis());
                    likesList.add(like);
                }
            }

            updateReactionMap(reaction, defaultReaction);

            mFireStore.collection(COLLECTIONS_POSTS).document(postList.get(position).getId()).update("likesList", likesList).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    notifyItemChanged(position);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getReactColor(String reactText) {
        switch (reactText) {
            case "Like":
                return "#0366d6";
            case "Love":
                return "#f0716b";
            case "Smile":
                return "#f0ba15";
            case "Wow":
                return "#f0ba15";
            case "Sad":
                return "#fde99c";
            case "Angry":
                return "#f15268";
            default:
                return "#616770";
        }
    }

    private void updateReactionMap(Reaction reaction, boolean defaultReaction) {
        Log.i("Testing", "" + defaultReaction + " " + reaction.getReactText() + " " + reaction.getReactIconId() + " " + reaction.getReactTextColor());
        if (defaultReaction) {
            return;
        }
        reactionTextMap.put(reaction.getReactText(), reaction);
    }

    private HashMap<String, Reaction> reactionTextMap = new HashMap<>();

    private int getReactIconId(String reactText) {
        if (reactionTextMap.containsKey(reactText)) {
            return reactionTextMap.get(reactText).getReactIconId();
        } else {
            switch (reactText) {
                case "Like":
                    return 2131165347;
                case "Love":
                    return 2131165342;
                case "Smile":
                    return 2131165341;
                case "Wow":
                    return 2131165360;
                case "Sad":
                    return 2131165356;
                case "Angry":
                    return 2131165329;
                default:
                    return 2131165340;

            }
        }
    }

    public interface PostAdapterDelegate {
        void onCommentsClicked(int position);

        void onProfileClicked(int position);
    }
}
