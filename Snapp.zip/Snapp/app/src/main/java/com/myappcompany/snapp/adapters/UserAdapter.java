package com.myappcompany.snapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_USERS;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private Context mContext;
    private FirebaseFirestore mFireStore;
    private List<Users> mUsers;
    private Users currentUser;
    private String followingStr;
    private String followStr;
    private boolean displayFollow;
    private Delegate delegate;

    public UserAdapter(Context mContext, FirebaseFirestore mFireStore, List<Users> mUsers, boolean displayFollow, Delegate delegate) {
        this.mContext = mContext;
        this.mFireStore = mFireStore;
        this.mUsers = mUsers;

        followingStr = mContext.getString(R.string.following);
        followStr = mContext.getString(R.string.follow);
        this.displayFollow = displayFollow;
        this.delegate = delegate;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.user_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final Users user = mUsers.get(position);

        holder.username.setText(user.getName());
        holder.fullname.setText(user.getEmail());
        Glide.with(mContext)
                .load(user.getProfileImageUrl() == null ? R.drawable.ic_profile : user.getProfileImageUrl())
                .placeholder(R.drawable.ic_profile)
                .error(R.drawable.ic_profile)
                .centerCrop()
                .into(holder.image_profile);

        if (displayFollow) {
            holder.btn_follow.setText(currentUser.getFollowing().contains(user.getEmail()) ? followingStr : followStr);
            holder.btn_follow.setVisibility(View.VISIBLE);
        } else {
            holder.btn_follow.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mUsers.size();
    }

    public void setCurrentUser(Users currentUser) {
        this.currentUser = currentUser;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView username;
        public TextView fullname;
        public CircleImageView image_profile;
        public Button btn_follow;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.username);
            fullname = itemView.findViewById(R.id.fullname);
            image_profile = itemView.findViewById(R.id.image_profile);
            btn_follow = itemView.findViewById(R.id.btn_follow);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (delegate != null) {
                        delegate.onItemClick(getAdapterPosition());
                    }
                }
            });

            btn_follow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Users user = mUsers.get(getAdapterPosition());
                    if (((Button) v).getText().toString().equals(followingStr)) {
                        // Unfollow
                        ArrayList<String> following = currentUser.getFollowing();
                        following.remove(user.getEmail());
                        currentUser.setFollowing(following);
                        mFireStore.collection(COLLECTIONS_USERS).document(FireBaseDataInstance.getInstance().getCurrentUserDocumentId()).update("following", following).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                notifyDataSetChanged();
                            }
                        });
                    } else {
                        // follow
                        ArrayList<String> following = currentUser.getFollowing();
                        following.add(user.getEmail());
                        currentUser.setFollowing(following);
                        mFireStore.collection(COLLECTIONS_USERS).document(FireBaseDataInstance.getInstance().getCurrentUserDocumentId()).update("following", following).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                notifyDataSetChanged();
                            }
                        });
                    }

                }
            });
        }
    }

    public interface Delegate {
        void onItemClick(int position);
    }
}
