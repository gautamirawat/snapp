package com.myappcompany.snapp.fireconstants;

public interface FireStoreConstants {
    String COLLECTIONS_USERS = "Users";
    String COLLECTIONS_POSTS = "Posts";
    String COLLECTIONS_CHATS = "Chats";

    String STORAGE_IMAGES = "ProfileImage";
    String STORAGE_POSTS = "PostsMedia";
}
