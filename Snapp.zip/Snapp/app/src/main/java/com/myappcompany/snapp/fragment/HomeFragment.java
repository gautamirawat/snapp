package com.myappcompany.snapp.fragment;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.activities.CommentActivity;
import com.myappcompany.snapp.activities.ProfileActivity;
import com.myappcompany.snapp.adapters.PostAdapter;
import com.myappcompany.snapp.camera.CameraPreviewActivity;
import com.myappcompany.snapp.model.Comment;
import com.myappcompany.snapp.model.Post;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;
import static com.google.firebase.firestore.Query.Direction.DESCENDING;
import static com.myappcompany.snapp.activities.CommentActivity.POST_OBJECT;
import static com.myappcompany.snapp.activities.ProfileActivity.EXTRA_IS_CURRENT_USER;
import static com.myappcompany.snapp.activities.ProfileActivity.EXTRA_PROFILE_EMAIL;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_FROM_REGISTER;
import static com.myappcompany.snapp.camera.CameraPreviewActivity.EXTRA_IS_GALLERY;
import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_POSTS;

public class HomeFragment extends Fragment {

    private PostAdapter postAdapter;
    private List<Post> postLists;
    private FirebaseFirestore mFireStore;
    private ArrayList<Users> usersList;
    private RecyclerView recyclerView;
    public SwipeRefreshLayout refreshLayout;
    private TextView noPostsTv;
    private Button postB;

    public HomeFragment() {
    }

    public HomeFragment(FirebaseFirestore mFireStore) {
        this.mFireStore = mFireStore;
    }

    private View rootView;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_home, container, false);

            noPostsTv = rootView.findViewById(R.id.no_posts_tv);
            postB = rootView.findViewById(R.id.post_b);

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
            recyclerView = rootView.findViewById(R.id.frag_home_rv);
            recyclerView.setLayoutManager(linearLayoutManager);

            refreshLayout = rootView.findViewById(R.id.refresh_layout);
            refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    init(true);
                }
            });

            postB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intentCamera = new Intent(getContext(), CameraPreviewActivity.class);
                    intentCamera.putExtra(EXTRA_FROM_REGISTER, false);
                    intentCamera.putExtra(EXTRA_IS_GALLERY, false);
                    startActivity(intentCamera);
                }
            });

            refreshLayout.setRefreshing(true);
            init(false);

        }
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void init(boolean forceRead) {
        FireBaseDataInstance.getInstance().readUsers(mFireStore, forceRead, new FireBaseDataInstance.Delegate() {
            @Override
            public void onComplete(Object object) {
                usersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();
                usersList.add(0, FireBaseDataInstance.getInstance().getCurrentUser());

                postLists = new ArrayList<>();
                postAdapter = new PostAdapter(getContext(), mFireStore, postLists, usersList, delegate);
                recyclerView.setAdapter(postAdapter);

                readPosts();
            }
        });
    }

    private void readPosts() {
        mFireStore.collection(COLLECTIONS_POSTS).orderBy("timeInMillis", DESCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            List<DocumentSnapshot> documents = task.getResult().getDocuments();
                            if (documents.size() > 0) {
                                postLists.clear();
                                for (DocumentSnapshot snapshot : documents) {
                                    Post post = snapshot.toObject(Post.class);
                                    postLists.add(post);
                                }
                                postAdapter.notifyDataSetChanged();
                            }
                        }
                        refreshLayout.setRefreshing(false);
                        noPostsTv.setVisibility(postLists.size() > 0 ? View.GONE : View.VISIBLE);
                        postB.setVisibility(postLists.size() > 0 ? View.GONE : View.VISIBLE);
                    }
                });

    }

    private int recentPostCommentsPosition;

    private final PostAdapter.PostAdapterDelegate delegate = new PostAdapter.PostAdapterDelegate() {
        @Override
        public void onCommentsClicked(int position) {
            if (refreshLayout.isRefreshing())
                return;

            recentPostCommentsPosition = position;
            Intent intent = new Intent(getContext(), CommentActivity.class);
            intent.putExtra(POST_OBJECT, postLists.get(position));
            startActivityForResult(intent, RQ_COMMENTS);
        }

        @Override
        public void onProfileClicked(int position) {
            Intent intent = new Intent(getContext(), ProfileActivity.class);
            intent.putExtra(EXTRA_PROFILE_EMAIL, postLists.get(position).getPostEmailId());
            intent.putExtra(EXTRA_IS_CURRENT_USER, postLists.get(position).getPostEmailId().equals(FireBaseDataInstance.getInstance().getCurrentUser().getEmail()));
            startActivity(intent);
        }
    };

    private int RQ_COMMENTS = 106;

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RQ_COMMENTS && resultCode == RESULT_OK) {
            ArrayList<Comment> commentsList = (ArrayList<Comment>) data.getSerializableExtra("commentsList");
            postLists.get(recentPostCommentsPosition).setCommentsList(commentsList);
            postAdapter.notifyDataSetChanged();
        }
    }
}
