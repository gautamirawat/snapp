package com.myappcompany.snapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;
import com.myappcompany.snapp.R;

public class NotificationFragment extends Fragment {

    private FirebaseFirestore mFireStore;

    public NotificationFragment(FirebaseFirestore mFireStore) {

        this.mFireStore = mFireStore;
    }

    public NotificationFragment() {

    }

    private View rootView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_notification, container, false);
        }
        return rootView;
    }
}
