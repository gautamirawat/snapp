package com.myappcompany.snapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.firebase.firestore.FirebaseFirestore;
import com.myappcompany.snapp.R;
import com.myappcompany.snapp.activities.ProfileActivity;
import com.myappcompany.snapp.adapters.UserAdapter;
import com.myappcompany.snapp.model.Users;
import com.myappcompany.snapp.singleton.FireBaseDataInstance;

import java.util.ArrayList;

import static com.myappcompany.snapp.activities.ProfileActivity.EXTRA_IS_CURRENT_USER;
import static com.myappcompany.snapp.activities.ProfileActivity.EXTRA_PROFILE_EMAIL;

public class SearchFragment extends Fragment {

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private FirebaseFirestore mFireStore;
    private ArrayList<Users> usersList = new ArrayList<>();
    private ArrayList<Users> masterUsersList = new ArrayList<>();
    public SwipeRefreshLayout refreshLayout;

    public SearchFragment() {
    }

    public SearchFragment(FirebaseFirestore mFireStore) {
        this.mFireStore = mFireStore;
    }

    private View rootView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_search, container, false);
            recyclerView = rootView.findViewById(R.id.recycler_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

            EditText searchEt = rootView.findViewById(R.id.search_bar);
            searchEt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    searchUsers(s.toString().toLowerCase());
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            refreshLayout = rootView.findViewById(R.id.refresh_layout);
            refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    init(true);
                }
            });

            refreshLayout.setRefreshing(true);
            init(false);
        }
        return rootView;
    }

    private void init(boolean forceRead) {
        FireBaseDataInstance.getInstance().readUsers(mFireStore, forceRead, new FireBaseDataInstance.Delegate() {
            @Override
            public void onComplete(Object object) {
                usersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();
                masterUsersList = (ArrayList<Users>) ((ArrayList<Users>) object).clone();

                userAdapter = new UserAdapter(getContext(), mFireStore, usersList, true, new UserAdapter.Delegate() {
                    @Override
                    public void onItemClick(int position) {
                        Users user = usersList.get(position);
                        Intent intent = new Intent(getContext(), ProfileActivity.class);
                        intent.putExtra(EXTRA_PROFILE_EMAIL, user.getEmail());
                        intent.putExtra(EXTRA_IS_CURRENT_USER, false);
                        getContext().startActivity(intent);
                    }
                });
                userAdapter.setCurrentUser(FireBaseDataInstance.getInstance().getCurrentUser());
                recyclerView.setAdapter(userAdapter);
                userAdapter.notifyDataSetChanged();

                refreshLayout.setRefreshing(false);
            }
        });
    }

    private void searchUsers(String string) {
        usersList.clear();
        for (Users user : masterUsersList) {
            if (user.getEmail().contains(string)) {
                usersList.add(user);
            }
        }
        userAdapter.notifyDataSetChanged();
    }
}
