package com.myappcompany.snapp.model;

import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.ArrayList;

public class Chat implements Serializable, Comparable<Chat> {
    private String id;
    private ArrayList<String> usersEmailsList;
    private ArrayList<Message> messagesList;
    private long latestMessageTimeInMillis;
    private String title;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<String> getUsersEmailsList() {
        return usersEmailsList;
    }

    public void setUsersEmailsList(ArrayList<String> usersEmailsList) {
        this.usersEmailsList = usersEmailsList;
    }

    public ArrayList<Message> getMessagesList() {
        return messagesList;
    }

    public void setMessagesList(ArrayList<Message> messagesList) {
        this.messagesList = messagesList;
    }

    public long getLatestMessageTimeInMillis() {
        return latestMessageTimeInMillis;
    }

    public void setLatestMessageTimeInMillis(long latestMessageTimeInMillis) {
        this.latestMessageTimeInMillis = latestMessageTimeInMillis;
    }

    @Override
    public int compareTo(Chat chat) {
        if (chat.getLatestMessageTimeInMillis() > getLatestMessageTimeInMillis())
            return 1;
        else if (chat.getLatestMessageTimeInMillis() < getLatestMessageTimeInMillis())
            return -1;
        return 0;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (obj == null) return false;
        if (!(obj instanceof Chat)) return false;
        Chat o = (Chat) obj;
        return o.id.equals(this.id);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
