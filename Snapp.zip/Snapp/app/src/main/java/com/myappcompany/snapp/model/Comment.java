package com.myappcompany.snapp.model;

import java.io.Serializable;

public class Comment implements Serializable, Comparable<Comment> {
    private String userEmail;
    private String comment;
    private long commentTimeInMillis;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public long getCommentTimeInMillis() {
        return commentTimeInMillis;
    }

    public void setCommentTimeInMillis(long commentTimeInMillis) {
        this.commentTimeInMillis = commentTimeInMillis;
    }

    @Override
    public int compareTo(Comment comment) {
        if (comment.getCommentTimeInMillis() > getCommentTimeInMillis())
            return -1;
        else if (comment.getCommentTimeInMillis() < getCommentTimeInMillis())
            return 1;
        return 0;
    }
}
