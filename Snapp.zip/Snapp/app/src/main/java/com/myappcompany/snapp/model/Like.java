package com.myappcompany.snapp.model;

import java.io.Serializable;

public class Like implements Serializable {
    private String userEmail;
    private String likeType;
    private long likeTimeInMillis;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getLikeType() {
        return likeType;
    }

    public void setLikeType(String likeType) {
        this.likeType = likeType;
    }

    public long getLikeTimeInMillis() {
        return likeTimeInMillis;
    }

    public void setLikeTimeInMillis(long likeTimeInMillis) {
        this.likeTimeInMillis = likeTimeInMillis;
    }
}
