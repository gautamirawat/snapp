package com.myappcompany.snapp.model;

import java.io.Serializable;

public class Message implements Serializable, Comparable<Message> {
    private String userEmail;
    private String message;
    private long messageTimeInMillis;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getMessageTimeInMillis() {
        return messageTimeInMillis;
    }

    public void setMessageTimeInMillis(long messageTimeInMillis) {
        this.messageTimeInMillis = messageTimeInMillis;
    }

    @Override
    public int compareTo(Message message) {
        if (message.getMessageTimeInMillis() > getMessageTimeInMillis())
            return -1;
        else if (message.getMessageTimeInMillis() < getMessageTimeInMillis())
            return 1;
        return 0;
    }
}
