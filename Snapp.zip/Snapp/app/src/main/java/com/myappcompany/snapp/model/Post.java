package com.myappcompany.snapp.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Post implements Serializable {
    private String id;
    private String postEmailId;
    private String postImage;
    private String description;
    private String publisher;
    private long timeInMillis;
    private ArrayList<Comment> commentsList = new ArrayList<>();
    private ArrayList<Like> likesList = new ArrayList<>();

    public String getPostEmailId() {
        return postEmailId;
    }

    public void setPostEmailId(String postEmailId) {
        this.postEmailId = postEmailId;
    }

    public String getPostImage() {
        return postImage;
    }

    public void setPostImage(String postImage) {
        this.postImage = postImage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public long getTimeInMillis() {
        return timeInMillis;
    }

    public void setTimeInMillis(long timeInMillis) {
        this.timeInMillis = timeInMillis;
    }

    public ArrayList<Comment> getCommentsList() {
        return commentsList;
    }

    public void setCommentsList(ArrayList<Comment> commentsList) {
        this.commentsList = commentsList;
    }

    public ArrayList<Like> getLikesList() {
        return likesList;
    }

    public void setLikesList(ArrayList<Like> likesList) {
        this.likesList = likesList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
