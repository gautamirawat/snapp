package com.myappcompany.snapp.singleton;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.myappcompany.snapp.model.Users;

import java.util.ArrayList;
import java.util.List;

import static com.myappcompany.snapp.fireconstants.FireStoreConstants.COLLECTIONS_USERS;

public class FireBaseDataInstance {

    private FireBaseDataInstance() {
    }

    private static FireBaseDataInstance mInstance;

    public static FireBaseDataInstance getInstance() {
        if (mInstance == null) {
            mInstance = new FireBaseDataInstance();
        }
        return mInstance;
    }

    private ArrayList<Users> usersList = new ArrayList<>();

    private Users currentUser;
    private String currentUserDocumentId;

    public void readUsers(FirebaseFirestore mFireStore, boolean forceRead, final Delegate delegate) {
        if (forceRead || usersList == null || usersList.size() == 0) {
            mFireStore.collection(COLLECTIONS_USERS)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                List<DocumentSnapshot> documents = task.getResult().getDocuments();
                                if (documents.size() > 0) {
                                    usersList.clear();
                                    for (DocumentSnapshot snapshot : documents) {
                                        Users user = snapshot.toObject(Users.class);
                                        if (!user.getId().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                                            usersList.add(user);
                                        } else {
                                            currentUserDocumentId = snapshot.getId();
                                            currentUser = user;
                                        }
                                    }
                                }
                            }
                            if (delegate != null) {
                                delegate.onComplete(usersList);
                            }
                        }
                    });
        } else {
            if (delegate != null) {
                delegate.onComplete(usersList);
            }
        }
    }

    public Users getCurrentUser() {
        return currentUser;
    }

    public String getCurrentUserDocumentId() {
        return currentUserDocumentId;
    }

    public interface Delegate {
        void onComplete(Object object);
    }
}
